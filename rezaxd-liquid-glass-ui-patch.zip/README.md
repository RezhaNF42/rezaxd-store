# Rezaxd Store — Liquid Glass UI refresh (frontend-only)

This patch refreshes the global visual system without changing API routes, authentication, Prisma models, checkout, product data, or server-side code.

## Included
- `src/app/globals.css`: deeper liquid-glass background, translucent panels, subtle cyan/violet glow, clearer keyboard focus, and reduced-motion support.

## Apply safely
1. Make a backup or create a separate branch before editing.
2. Replace `src/app/globals.css` with the file included here.
3. Run `npm run build`.
4. Check the homepage and `/admin`, `/pesanan`, `/akun`, `/testimoni` on mobile and desktop.
5. Deploy a Preview deployment first. Merge to `main` only after reviewing the preview.

## Scope note
This is a conservative first pass. Existing React components and backend files are intentionally untouched. The GitHub integration currently returns `403 Resource not accessible by integration` when creating a branch, so this package is prepared for review/application rather than pushed to the repository.
